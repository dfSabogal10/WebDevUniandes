var express = require('express');
var app = express();
var MongoClient = require('mongodb').MongoClient
, assert = require('assert');
var router = express.Router();
var url = 'mongodb://javier:123456789@ds119020.mlab.com:19020/mispollas';;
const routes = require('./routes/index');
routes(app);


app.set('port', (process.env.PORT || 5000));
app.use(express.static(__dirname + '/public'));

// views is directory for all template files
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/', function(request, response) {
  response.render('pages/index');
});

MongoClient.connect(url, function(err, db) {
  assert.equal(null, err);
  console.log("Connected successfully to Database");
  db.close();
});


app.listen(app.get('port'), function() {
  console.log('Node app is running on port', app.get('port'));
});

/* GET home page. */
//app.get('/tetas', function(req, res) {
//  findDocuments( {}, tweets => res.render('index', { tweets : tweets } ) );

 //findDocuments( {}, tweets => res.send( { tweets : tweets })  ) ;

//});


var findDocuments = function(query, callback) {

  // Use connect method to connect to the server
  MongoClient.connect( url, function(err, db) {
    assert.equal(null, err);
    console.log("Connected successfully to Database");

    // Get the documents collection
    var collection = db.collection( "usuarios" );

    collection.find(query).toArray(function(err, docs) {
      assert.equal(err, null);

      callback(docs);
      db.close();

      console.log("Found the following records" + docs );

    });


  });


}
