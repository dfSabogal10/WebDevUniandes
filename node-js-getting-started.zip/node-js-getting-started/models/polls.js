var request = require('request');
exports.Polla = Polla;



var Polla = function (name) {
};


exports.list = (req, res) => {


var day = req.query.day
var month = req.query.month
var year = req.query.year

var day2 = req.query.day2
var month2 = req.query.month2
var year2 = req.query.year2

//console.log(day);


var retorno =   getGames(day,month,year,day2,month2,year2,
function(response){
var myObject = JSON.parse(response);
var jsonRetornolist = '{"fixtures":[';

for (var i = 0; i < myObject.fixtures.length; i++) {
jsonRetorno= jsonRetorno+  '{';
jsonRetorno= jsonRetorno+  '"homeTeamName":"'+ myObject.fixtures[i].homeTeamName +'",';
jsonRetorno= jsonRetorno+  '"awayTeamName":"'+ myObject.fixtures[i].awayTeamName +'",';
jsonRetorno= jsonRetorno+  '"date":"'+ myObject.fixtures[i].date +'",';
jsonRetorno= jsonRetorno+  '"matchday":"'+ myObject.fixtures[i].matchday +'",';
jsonRetorno= jsonRetorno+  '"status":"'+ myObject.fixtures[i].status +'",';
if(i<  myObject.fixtures.length -1)
{jsonRetorno = jsonRetorno+  '},';
}
else {
  jsonRetorno= jsonRetorno+  '}';
}

}
jsonRetorno= jsonRetorno+ ']}';
console.log(jsonRetorno);
res.json( jsonRetorno);
})
}


function getGames(day,month,year,day2,month2,year2,callback) {
//  request('http://api.football-data.org/v1/competitions/440/fixtures?timeFrameStart=2017-03-05&timeFrameEnd=2017-03-20', function (error, response, body) {
 request('http://api.football-data.org/v1/competitions/440/fixtures?timeFrameStart='+year+'-'+month+'-'+day+'&timeFrameEnd='+year2+'-'+month2+'-'+day2, function (error, response, body) {

    if (!error && response.statusCode == 200) {
      return    callback(body);
     }
})
}
